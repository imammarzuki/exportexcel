<?php 
include "koneksi.php";
include "excel_reader2.php";
$target = basename($_FILES['filepegawai']['name']) ;
move_uploaded_file($_FILES['filepegawai']['tmp_name'], $target);
chmod($_FILES['filepegawai']['name'],0777);
$data = new Spreadsheet_Excel_Reader($_FILES['filepegawai']['name'],false);
$jumlah_baris = $data->rowcount($sheet_index=0);
$berhasil = 0;
for ($i=2; $i<=$jumlah_baris; $i++){
	$nama     = $data->val($i, 1);
	$alamat   = $data->val($i, 2);
	$telepon  = $data->val($i, 3);
 
	if($nama != "" && $alamat != "" && $telepon != ""){
		$sql="insert into data_pegawai values('','$nama','$alamat','$telepon')";
		$query=mysqli_query($nyambung,$sql);
		$berhasil++;
	}
}
// hapus kembali file .xls yang di upload tadi
unlink($_FILES['filepegawai']['name']);
?>
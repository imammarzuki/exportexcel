<!DOCTYPE html>
<html>
<head>
<title>Data di Database</title>
</head>
<body>
<h1>Daftar Nama Pegawai</h1>
<table border="1" cellpadding="10" cellspacing="0">
<tr><th>No</th><th>Nama</th><th>ALamat</th><th>Telepon</th></tr>
<?php 
include "koneksi.php";
$sql2="select count(*) from data_pegawai";
$query2=mysqli_query($nyambung,$sql2);
$baris2=mysqli_fetch_row($query2);
echo "Jumlah Pegawai $baris2[0] Orang";
$sql="select * from data_pegawai";
$query=mysqli_query($nyambung,$sql);
$no=1;
while($baris = mysqli_fetch_array($query)){
	$id=$baris[0];
	$nama=$baris[1];
	$alamat=$baris[2];
	$telepon=$baris[3];
	echo "<tr><td>$no</td><td>$nama</td><td>$alamat</td><td>$telepon</td></tr>";
	$no++;
}
?>
</table> 
</body>
</html>